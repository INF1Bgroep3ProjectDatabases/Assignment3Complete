﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;
using System.Data;
using System.Data.SqlClient;

namespace SomerenDAL
{
    public class DrinkDao : BaseDao
    {
        public List<Drink> GetAllDrinks()
        {
            string query = "SELECT DrinkID, [Name], Stock, SalesPrice, VAT, AlcholPercent,AmountSold, TotalSalesPrice FROM [Drinks]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }
        private List<Drink> ReadTables(DataTable dataTable)
        {
            List<Drink> Drinks = new List<Drink>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Drink drink = new Drink()
                {
                    DrinkID = (int)dr["DrinkID"],
                    Name = (string)dr["Name"],
                    Stock = (int)dr["Stock"],
                    SalesPrice =(int) (decimal)dr["SalesPrice"],
                    VAT = (decimal)dr["VAT"],
                    AlcholPercent = (decimal)dr["AlcholPercent"],
                    AmountSold = (int)dr["amountsold"]                
                };
                Drinks.Add(drink);
            }
            return Drinks;
        }
        public void DrinkSold(int drinkID, int StudentID)
        {
            string query = $"UPDATE Drinks SET Stock = Stock-1, AmountSold = AmountSold+1 WHERE DrinkID = '{drinkID}'";
            string query1 = $"UPDATE Student SET DrinksBought = DrinksBought+1 WHERE StudentID = '{StudentID}'";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
            ExecuteEditQuery(query1, sqlParameters);
        }
    }
}
