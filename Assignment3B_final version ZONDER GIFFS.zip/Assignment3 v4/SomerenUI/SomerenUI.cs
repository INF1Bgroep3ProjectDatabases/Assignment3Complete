﻿using SomerenLogic;
using SomerenModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SomerenUI
{
    public partial class SomerenUI : Form
    {
        public SomerenUI()
        {
            InitializeComponent();
        }

        private void SomerenUI_Load(object sender, EventArgs e)
        {
            showPanel("Dashboard");
        }

        private void showPanel(string panelName)
        {

            if (panelName == "Dashboard")
            {
                // hide all other panels
                pnlStudents.Hide();
                pnlRooms.Hide();
                pnlTeachers.Hide();
                pnlDrinks.Hide();
                pnlCashRegister.Hide();
                // show dashboard
                pnlDashboard.Show();
                imgDashboard.Show();
            }
            else if (panelName == "Students")
            {
                // hide all other panels
                pnlDashboard.Hide();
                imgDashboard.Hide();
                pnlRooms.Hide();
                pnlTeachers.Hide();
                pnlDrinks.Hide();
                pnlCashRegister.Hide();
                // show students
                pnlStudents.Show();

                listViewStudents.Items.Clear();
                try
                {
                    // fill the students listview within the students panel with a list of students
                    StudentService studService = new StudentService();
                    List<Student> studentList = studService.GetStudents(); ;

                    listViewStudents.View = View.Details;
                    foreach (Student s in studService.GetStudents())
                    {
                        ListViewItem li = new ListViewItem(s.Number.ToString());
                        li.SubItems.Add(s.Firstname);
                        li.SubItems.Add(s.Lastname);
                        listViewStudents.Items.Add(li);
                    }

                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the students: " + e.Message);
                }
            }
            else if (panelName == "Lecturers")
            {
                pnlDashboard.Hide();
                imgDashboard.Hide();
                pnlStudents.Hide();
                pnlRooms.Hide();
                pnlDrinks.Hide();
                pnlCashRegister.Hide();

                pnlTeachers.Show();

                listViewTeachers.Items.Clear();
                try
                {
                    TeacherService teacherService = new TeacherService();
                    List<Teacher> teachList = teacherService.GetTeacher();
                    foreach (Teacher t in teachList)
                    {
                        ListViewItem li = new ListViewItem(t.Number.ToString());
                        li.SubItems.Add(t.Name);
                        listViewTeachers.Items.Add(li);
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the Teachers: " + e.Message);
                }
            }
            else if (panelName == "Rooms")
            {

                // hide all other panels
                pnlDashboard.Hide();
                imgDashboard.Hide();
                pnlStudents.Hide();
                pnlTeachers.Hide();
                pnlDrinks.Hide();
                pnlCashRegister.Hide();

                pnlRooms.Show();

                listViewRooms.Items.Clear();
                try
                {
                    // fill the students listview within the students panel with a list of students
                    RoomService roomService = new RoomService();
                    List<Room> roomList = roomService.GetRooms();
                    foreach (Room r in roomList)
                    {
                        ListViewItem li = new ListViewItem(r.Number.ToString());
                        li.SubItems.Add(r.Capacity.ToString());
                        li.SubItems.Add(r.Type.ToString());
                        listViewRooms.Items.Add(li);
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show("Something went wrong while loading the Rooms: " + e.Message);
                }
            }
            else if (panelName == "Drinks")
            {
                pnlDashboard.Hide();
                imgDashboard.Hide();
                pnlStudents.Hide();
                pnlTeachers.Hide();
                pnlRooms.Hide();
                pnlCashRegister.Hide();

                pnlDrinks.Show();

                listViewDrinks.Items.Clear();

                try
                {
                    DrinkService drinkService = new DrinkService();
                    List<Drink> drinkList = drinkService.GetDrinks();
                    foreach (Drink dr in drinkList)
                    {
                        ListViewItem li = new ListViewItem(dr.DrinkID.ToString());
                        li.SubItems.Add(dr.Name);
                        if (dr.Stock < 10)
                        {
                            li.SubItems.Add("Stock nearly depleted".ToString());
                        }
                        else
                        {
                            li.SubItems.Add("Stock Sufficient".ToString());
                        }
                        li.SubItems.Add(dr.SalesPrice.ToString());
                        li.SubItems.Add(dr.VAT.ToString());
                        li.SubItems.Add(dr.AlcholPercent.ToString());
                        listViewDrinks.Items.Add(li);
                    }
                }
                catch (Exception e)
                {

                    MessageBox.Show("Something went wrong while loading the Drinks: " + e.Message);
                }

            }
            else if (panelName == "Cash Register")
            {
                pnlDashboard.Hide();
                imgDashboard.Hide();
                pnlStudents.Hide();
                pnlTeachers.Hide();
                pnlRooms.Hide();
                pnlDrinks.Hide();

                pnlCashRegister.Show();

                try
                {
                    StudentService studService = new StudentService();
                    List<Student> studentList = studService.GetStudents(); ;

                    listStudents.View = View.Details;
                    foreach (Student s in studService.GetStudents())
                    {
                        ListViewItem listViewItem = new ListViewItem(s.Number.ToString());
                        listViewItem.SubItems.Add(s.Firstname);
                        listViewItem.SubItems.Add(s.Lastname);
                        listStudents.Items.Add(listViewItem);
                    }

                }
                catch (Exception e)
                {

                    MessageBox.Show("Something went wrong while loading the students: " + e.Message);
                }

                try
                {
                    DrinkService drinkService = new DrinkService();
                    List<Drink> drinkList = drinkService.GetDrinks();
                    DrinkRegisterList.View = View.Details;
                    foreach (Drink dr in drinkList)
                    {
                        ListViewItem li = new ListViewItem(dr.DrinkID.ToString());
                        li.SubItems.Add(dr.Name);
                        li.SubItems.Add(dr.SalesPrice.ToString());
                        li.SubItems.Add(dr.Stock.ToString());
                        DrinkRegisterList.Items.Add(li);
                    }
                }
                catch (Exception e)
                {

                    MessageBox.Show("Something went wrong while loading the Drinks: " + e.Message);
                }


            }
            }
        private void dashboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dashboardToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            showPanel("Dashboard");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void imgDashboard_Click(object sender, EventArgs e)
        {
            MessageBox.Show("What happens in Someren, stays in Someren!");
        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Students");
        }

        private void roomsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Rooms");
        }

        private void lecturersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Lecturers");
        }

        private void liqourStockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Drinks");
        }

        private void registerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            showPanel("Cash Register");
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            

            try
            {
                if (listStudents.SelectedItems.Count == 0 && DrinkRegisterList.SelectedItems.Count == 0)
                {
                    throw new Exception("There are no students and drinks selected.\nPlease try again.");
                }
                else if (listStudents.SelectedItems.Count == 0)
                {
                    throw new Exception("There are no students selected.\nPlease try again.");
                }
                else if (DrinkRegisterList.SelectedItems.Count == 0)
                {
                    throw new Exception("There are no drinks selected.\nPlease try again.");
                }
                
                int SelectedDrinkID = int.Parse(DrinkRegisterList.SelectedItems[0].SubItems[0].Text);
                int SelectedStudentID = int.Parse(listStudents.SelectedItems[0].SubItems[0].Text);
                
                int totaltestprijs = 0;

                for (int i = 0; i < DrinkRegisterList.SelectedItems.Count; i++)
                {
                    int SelectedPriceItem = int.Parse(DrinkRegisterList.SelectedItems[i].SubItems[2].Text);
                    totaltestprijs += SelectedPriceItem;
                }
                
                DialogResult dialogResult = MessageBox.Show($"The total price of your purchase will be: €{totaltestprijs}");

                DrinkService drinkService = new DrinkService();
                drinkService.SoldDrink(SelectedDrinkID, SelectedStudentID);
                      
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
