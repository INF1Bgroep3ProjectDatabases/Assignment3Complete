﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;
using SomerenDAL;

namespace SomerenLogic
{
    public class DrinkService
    {
        DrinkDao drinkdb;
        public DrinkService()
        {
            drinkdb = new DrinkDao();
        }
        public List<Drink> GetDrinks()
        {
            List<Drink> Drinks = drinkdb.GetAllDrinks();
            return Drinks;
        }
        public void SoldDrink(int drinkid, int studentid)
        {
            drinkdb.DrinkSold(drinkid, studentid);
        }
        public void UpdateDrink(int UpdateID, string UpdateName, string UpdateStock, string UpdatePrice, string UpdateAlchol)
        {
            drinkdb.UpdateDrink(UpdateID, UpdateName, UpdateStock, UpdatePrice, UpdateAlchol);
        }
        public void AddDrink(string name, string stock, string price, string alchol, string VAT)
        {
            drinkdb.AddDrink(name, stock, price, alchol, VAT);
        }
        public void DeleteDrink(int id)
        {
            drinkdb.DeleteDrink(id);
        }
        public Drink GetDrinkByID(int id)
        {
            return drinkdb.GetDrinkById(id);
        }
    }
}
