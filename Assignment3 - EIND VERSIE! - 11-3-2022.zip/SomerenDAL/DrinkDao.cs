﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;
using System.Data;
using System.Data.SqlClient;

namespace SomerenDAL
{
    public class DrinkDao : BaseDao
    {
        public List<Drink> GetAllDrinks()
        {
            string query = "SELECT DrinkID, [Name], Stock, SalesPrice, VAT, AlcholPercent,AmountSold, TotalSalesPrice FROM [Drinks]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }
        public Drink GetDrinkById(int id)
        {
            string query = $"SELECT DrinkID, [Name], Stock, SalesPrice, VAT, AlcholPercent FROM [Drinks] WHERE DrinkID = {id}";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTable(ExecuteSelectQuery(query, sqlParameters));
        }
        public void AddDrink(string name, string stock, string price, string alchol, string VAT)
        {
            string query = $"INSERT INTO Drinks (SalesPrice, Stock, VAT, AlcholPercent, [Name], AmountSold) VALUES('{price}','{stock}','{VAT}','{alchol}','{name}', '0')";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
        public void DeleteDrink(int id)
        {
            string query = $"DELETE FROM Drinks WHERE DrinkID = {id}";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
        public void UpdateDrink(int UpdateID, string UpdateName, string UpdateStock, string UpdatePrice, string UpdateAlchol)
        {
            string query = $"UPDATE Drinks SET [Name] = '{UpdateName}', Stock = '{UpdateStock}', SalesPrice = '{UpdatePrice}', AlcholPercent = '{UpdateAlchol}' WHERE DrinkID = '{UpdateID}'";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
        public void DrinkSold(int drinkID, int StudentID)
        {
            string query = $"UPDATE Drinks SET Stock = Stock-1, AmountSold = AmountSold+1 WHERE DrinkID = '{drinkID}'";
            string query1 = $"UPDATE Student SET DrinksBought = DrinksBought+1 WHERE StudentID = '{StudentID}'";
            string query2 = $"UPDATE sales SET totalsales = totalsales +1";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
            ExecuteEditQuery(query1, sqlParameters);
            ExecuteEditQuery(query2, sqlParameters);

        }
        private List<Drink> ReadTables(DataTable dataTable)
        {
            List<Drink> Drinks = new List<Drink>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Drink drink = new Drink()
                {
                    DrinkID = (int)dr["DrinkID"],
                    Name = (string)dr["Name"],
                    Stock = (int)dr["Stock"],
                    SalesPrice = (decimal)dr["SalesPrice"],
                    VAT = (decimal)dr["VAT"],
                    AlcholPercent = (decimal)dr["AlcholPercent"],
                    AmountSold = (int)dr["amountsold"]

                };
                Drinks.Add(drink);
            }
            return Drinks;
        }
        private Drink ReadTable(DataTable dataTable)
        {
            Drink drink = new Drink();
            foreach (DataRow dr in dataTable.Rows)
            {
                drink = new Drink()
                {
                    DrinkID = (int)dr["DrinkID"],
                    Name = (string)dr["Name"],
                    Stock = (int)dr["Stock"],
                    SalesPrice = (decimal)dr["SalesPrice"],
                    VAT = (decimal)dr["VAT"],
                    AlcholPercent = (decimal)dr["AlcholPercent"],
                    AmountSold = (int)dr["amountsold"]
                };
            }
            return drink;
        }
    }
}
