﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;
using System.Data;
using System.Data.SqlClient;

namespace SomerenDAL
{
    public class SalesDAO : BaseDao
    {
        public List<Sales> GetAllSales()
        {
            string query = "SELECT TotalSales, NumberOfCustomers, Turnover FROM [sales]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }
        private List<Sales> ReadTables(DataTable dataTable)
        {
            List<Sales> sales = new List<Sales>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Sales sale = new Sales()
                {
                    TotalSales = (int)dr["TotalSales"],
                    NumberOfCustomers = (int)dr["NumberOfCustomers"],
                    Turnover = (int)dr["Turnover"],

                };
                sales.Add(sale);
            }
            return sales;
        }

        public void SendTurnover(int SelectedPriceItem)
        {
            string query = $"UPDATE sales SET Turnover = Turnover +{SelectedPriceItem}";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }

        public void SendNumberOfCustomers()
        {
            string query = $"UPDATE sales SET NumberOfCustomers = NumberOfCustomers + 1";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            ExecuteEditQuery(query, sqlParameters);
        }
    }
}