﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;
using SomerenDAL;

namespace SomerenLogic
{
    public class SalesService
    {
        SalesDAO salesdb;
        public SalesService()
        {
            salesdb = new SalesDAO();
        }
        public List<Sales> GetSales()
        {
            List<Sales> sales = salesdb.GetAllSales();
            return sales;
        }

        public void CalculateTurnover(int SelectedPriceItem)
        {
            salesdb.SendTurnover(SelectedPriceItem);
        }

        public void DecideNumberOfCustomers()
        { 
            salesdb.SendNumberOfCustomers();
        }


    }
}
