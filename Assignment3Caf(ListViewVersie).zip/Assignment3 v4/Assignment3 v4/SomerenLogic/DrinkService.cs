﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;
using SomerenDAL;

namespace SomerenLogic
{
    public class DrinkService
    {
        DrinkDao drinkdb;
        public DrinkService()
        {
            drinkdb = new DrinkDao();
        }
        public List<Drink> GetDrinks()
        {
            List<Drink> Drinks = drinkdb.GetAllDrinks();
            return Drinks;
        }

        public void SoldDrink(int drinkid, int studentid)
        {
            drinkdb.DrinkSold(drinkid, studentid);
        }       
    }
}
