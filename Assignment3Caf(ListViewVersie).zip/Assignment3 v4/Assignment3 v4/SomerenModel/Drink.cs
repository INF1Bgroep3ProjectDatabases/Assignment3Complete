﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Drink
    {
        public int DrinkID { get; set; }
        public string Name { get; set; }
        public int SalesPrice { get; set; }
        public int Stock { get; set; }
        public decimal VAT { get; set; }
        public decimal AlcholPercent { get; set; }
        public int AmountSold { get; set; }
    }
}