﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SomerenModel;
using System.Data;
using System.Data.SqlClient;

namespace SomerenModel
{
    public class Sales
    { 
        public int TotalSales { get; set; }
        public int Turnover { get; set; }
        public int NumberOfCustomers { get; set; }
    }
}
